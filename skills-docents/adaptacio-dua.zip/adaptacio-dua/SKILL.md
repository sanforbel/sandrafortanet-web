---
name: adaptacio-dua
description: >-
  Adapta una activitat, un examen, un text o una fitxa perquè siga accessible a tot l'alumnat, aplicant el Disseny Universal per a l'Aprenentatge (DUA) i les mesures de resposta educativa de la normativa valenciana (Decret 104/2018 i Ordre 20/2019), en qualsevol etapa. Genera la versió adaptada llesta per a usar (lectura fàcil, suport visual, bastides, opcions d'expressió, ampliació) i una nota breu per al docent. Usa-la sempre que un docent diga "adapta esta activitat", "fes-ho més accessible", "versió en lectura fàcil", "per a un alumne nouvingut", "alumnat amb NESE", "DUA", "adaptación curricular", "adaptar el examen", o enganxe un material i parle de dificultats concretes de l'alumnat.
---

# Adaptació DUA · Comunitat Valenciana

L'objectiu no és fer una "fitxa més fàcil" per a una persona, sinó retirar les barreres que impedixen que el grup arribe al mateix aprenentatge. Primer DUA per a tothom (nivell universal); després, si cal, ajustos personalitzats.

Llig `references/etapes.md` (apartat d'inclusió i de l'etapa), `references/llengua.md` i `references/privacitat.md`. Per a citar normativa, `references/normativa-cv.md`.

## Flux
1. **Material**: demana l'activitat, el text o l'examen original (enganxat o adjunt) si encara no l'ha passat.
2. **Barreres, no etiquetes** (una sola tanda, amb botons si n'hi ha):
   - etapa i curs;
   - què vol que aprenga o demostre l'alumnat amb esta activitat (l'objectiu que no es pot perdre);
   - quines barreres observa: comprensió lectora, atenció, llengua d'escolarització, motricitat fina, visió o audició, organització, ansietat davant d'exàmens, ritme ràpid o necessitat de repte…
   Si el docent dona un diagnòstic, traduïx-lo tu a barreres funcionals i no el repetisques en el material.
3. **Entrega**, en este ordre:
   - **Versió universal (DUA)** de l'activitat, pensada per a tot el grup.
   - **Ajustos personalitzats** només per a les barreres indicades, com a variants curtes de la mateixa activitat.
   - **Ampliació** per a qui necessita més repte.
   - **Nota per al docent** (màxim 6 línies): què has canviat, per què, i com avaluar sense rebaixar l'objectiu.

## Repertori de mesures
**Representació (com arriba la informació)**
- Lectura fàcil: frases curtes, una idea per frase, ordre lògic, paraules freqüents, sense dobles negacions, tipografia gran i espaiat generós.
- Glossari de 5-8 paraules clau amb definició senzilla (i traducció a la llengua familiar si l'alumne és nouvingut i el docent ho vol).
- Suport visual: esquema, pictogrames (indica on anirien), exemple resolt.
- Instruccions numerades i separades del contingut.

**Acció i expressió (com ho demostren)**
- Opcions: escrit, oral, dibuix comentat, mapa conceptual, gravació breu.
- Bastides: inicis de frase, plantilles, llistes de comprovació, preguntes guia.
- Divisió de tasques llargues en passos amb punts de control.

**Implicació (per què hi entren)**
- Connexió amb la vida de l'alumnat, possibilitat de triar, treball en parella amb rols, objectius a curt termini, retroacció immediata.

**Exàmens**
- Menys ítems per pàgina, enunciats en negreta curta, espai per a respondre, opció de resposta oral, temps ampliat, una pregunta d'exemple resolta, mateixos criteris d'avaluació.

## Criteris de qualitat
- L'objectiu d'aprenentatge **no es rebaixa**; canvia el camí. Si una adaptació l'altera (ACIS, només a partir de l'ESO), digues-ho clarament perquè ho decidisca l'equip docent i l'orientació.
- Res d'infantilitzar a Secundària, Batxillerat o FP: lectura fàcil no vol dir to de Primària.
- Tot el material va sense noms reals de l'alumnat.
- Revisió lingüística de `llengua.md`.

## Format
Si l'entorn oferix documents editables, entrega-ho com a document; si pots crear fitxers Word, en .docx imprimible amb tipografia gran; si no, en el xat. Oferix en una línia la versió en joc o en tres nivells (`joc-interactiu-aula`, `material-graduat`).
