---
name: comunicacio-families
description: >-
  Redacta circulars, avisos, missatges i informes per a les famílies (eixides, reunions, normes, avaluació, convocatòries, felicitacions), en un llenguatge clar i proper, en valencià, castellà o en les dos llengües, i amb versió en lectura fàcil o traduïda per a famílies nouvingudes. Respecta la protecció de dades i el marc del centre. Usa-la sempre que un docent o equip directiu diga "fes una circular", "escriu un missatge a les famílies", "avís per a Web Família", "nota informativa", "carta a los padres", "convocatòria de reunió", "autorització d'eixida" o "explica-ho perquè ho entenguen totes les famílies".
---

# Comunicació amb les famílies

Una comunicació ben feta es llig en mig minut i deixa clar què ha de fer la família i quan. Les famílies són diverses (en llengua, temps i familiaritat amb el sistema educatiu): escriu perquè tothom l'entenga a la primera.

Llig `references/llengua.md` i `references/privacitat.md`. Si cal citar normativa (avaluació, convivència, inclusió, llengua base de la Llei 1/2024), usa només `references/normativa-cv.md`.

## Flux
1. Recull, si no ho ha dit (una sola tanda, amb botons si n'hi ha):
   - tipus de comunicació i finalitat;
   - etapa i curs als quals va;
   - dades clau: data, hora, lloc, cost, termini, què han de portar o tornar;
   - canal (circular en paper, plataforma del centre, correu, missatge curt);
   - llengües: valencià, castellà, bilingüe o traducció a una altra llengua; i si cal versió de lectura fàcil.
2. Genera la comunicació. No demanes més del que necessites: si falta una dada, deixa un espai marcat entre claudàtors.

## Estructura
- **Títol o assumpte** que ja diga l'essencial ("Eixida al Museu de Belles Arts, dijous 12 de desembre").
- **Primera frase amb el més important**: què, quan i què ha de fer la família.
- **Detalls** en llista curta: horari, lloc, material, cost, termini.
- **Acció requerida** destacada (autorització, resposta, pagament) amb la data límit.
- **Contacte** per a dubtes i signatura (tutor o tutora, equip directiu).
- Si hi ha autorització, un **retall** amb nom de l'alumne o alumna, curs, signatura i data.

## Versions
- **Bilingüe**: les dos llengües completes, una després de l'altra o en dos columnes, amb el mateix contingut.
- **Lectura fàcil**: frases curtes, una idea per línia, paraules comunes, dates escrites completes ("dijous 12 de desembre"), icones suggerides on ajuden.
- **Traducció** a una altra llengua: avisa en una línia que convé que una persona que la domine la revise abans d'enviar-la, sobretot si conté instruccions importants.
- **Missatge curt** per a aplicacions de mensatgeria o plataforma: màxim 4-5 línies amb l'essencial i l'enllaç o document adjunt.

## To i límits
- Proper i respectuós, sense tecnicismes pedagògics ni sigles sense explicar.
- Missatges delicats (incidents, absentisme, rendiment): neutrals, centrats en fets i en col·laboració, sense judicis, i proposant una via de diàleg (tutoria). Mai amb dades d'altres alumnes.
- No incloure dades de salut ni informació personal sensible en comunicacions generals.
- Revisió lingüística de `llengua.md`.

## Format
Text llest per a copiar en el xat; si és una circular per a imprimir, document editable o .docx. Si el docent té un correu connectat i vol enviar-la, prepara només l'esborrany i espera la seua confirmació.
