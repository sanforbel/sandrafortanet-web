---
name: joc-interactiu-aula
description: >-
  Convertix qualsevol contingut (un tema, un text, vocabulari, una unitat) en un joc interactiu HTML per a l'aula, en un sol fitxer que s'obri al navegador, es projecta a la pissarra digital o s'incrusta a Google Sites o a la plataforma del centre: qüestionari amb mode equips, memory de parelles o escape room amb proves encadenades. Adapta el nivell a l'etapa (Infantil, Primària, ESO, Batxillerat, FP) i no envia cap dada a internet. Usa-la sempre que un docent diga "fes-me un joc", "un quiz", "un kahoot", "un trivial", "un escape room", "un memory", "gamifica este tema", "un repàs divertit", "un juego para clase", o vulga repassar continguts d'una manera interactiva.
---

# Joc interactiu per a l'aula

El joc funciona quan el contingut és rigorós i la dinàmica és senzilla: una pantalla clara, botons grans i un motiu per a jugar en equip. La plantilla ja resol la part tècnica; el teu treball és fer preguntes bones.

Llig l'apartat de l'etapa de `references/etapes.md`, `references/llengua.md` i `references/privacitat.md`.

## Flux
1. Recull (una sola tanda, amb botons si n'hi ha):
   - etapa i curs;
   - contingut (que l'enganxe o l'adjunte, o el tema i el que han de saber);
   - tipus de joc: **qüestionari** (recomanat per a repassar), **memory** (vocabulari, conceptes i definicions, parelles), **escape room** (repte final d'unitat);
   - nombre d'ítems (per defecte: 10 preguntes, 8 parelles o 5 proves) i llengua.
2. Crea el contingut i genera el fitxer.
3. Comprova'l i entrega'l.

## Generar el fitxer
1. Escriu un JSON amb l'estructura documentada a la plantilla (`assets/plantilla-joc.html`, comentari "Format"):
   - `quiz`: `preguntes` amb `pregunta`, `opcions` (3-4), `correcta` (índex des de 0) i `explicacio` breu.
   - `memory`: `parelles` com a llistes de dos textos curts (màxim 12).
   - `escape`: `proves` amb `narrativa`, `enigma`, `resposta` (text o llista de respostes acceptades) i `pista`.
   - `titol`, `subtitol`, `final`, `peu` (per exemple, el nom del docent o del centre si el vol) i `llengua` (`ca` o `es`).
2. Executa `python3 scripts/genera_joc.py dades.json nom-del-joc.html`. L'script valida les dades i avisa si n'hi ha alguna malament.
3. Si l'entorn permet publicar pàgines (artefactes), publica-la perquè el docent tinga un enllaç; si no, entrega el fitxer .html.

Si el docent vol un tipus de joc que la plantilla no fa (ordenar, classificar, ruleta, sopa de lletres…), construïx-lo en un sol fitxer HTML seguint les mateixes regles: sense dependències externes, botons d'almenys 48 px, contrast alt, tema clar i fosc, i tot en una pantalla de mòbil o de pissarra.

## Qualitat del contingut
- **Qüestionari**: una sola resposta correcta i inequívoca; distractors plausibles que revelen errors típics (no absurds); l'explicació diu per què, en una frase. Barreja preguntes de record, comprensió i aplicació.
- **Memory**: textos de 1-6 paraules per carta, perquè es lligen de lluny.
- **Escape room**: una narrativa breu que lliga les proves; cada resposta és una paraula o un número fàcil d'escriure (accepta variants amb i sense accents, la plantilla ja normalitza majúscules i accents).
- Contingut correcte i contrastat. Si el docent n'aporta un text, només preguntes que es puguen respondre amb ell.

## Adaptació a l'etapa
- **Infantil**: millor memory amb imatges o paraules molt curtes, i joc guiat pel docent a la pissarra. Poques cartes (4-6 parelles).
- **Primària**: preguntes curtes, lectura fàcil; recorda que el Decret 96/2026 limita l'ús de dispositius, així que proposa'l per a la pissarra digital en gran grup i en sessions curtes.
- **ESO i Batxillerat**: preguntes d'aplicació i d'anàlisi; mode equips per a dinamitzar.
- **FP**: casos del sector (què faries si…, quin protocol s'aplica…).

## Comprovació
- Revisa que cada `correcta` apunta a la resposta bona.
- Revisa ortografia i llengua (`llengua.md`).
- Cap nom d'alumne en el joc.

## Entrega
Una línia amb què fa el joc i com usar-lo (pantalla completa amb F11, botó "Equips" per a jugar per grups). Oferix en una línia fer-ne una altra versió (un altre tipus de joc o un altre nivell).
