#!/usr/bin/env python3
"""Omple la plantilla del joc amb un JSON de dades i escriu un HTML autocontingut.

Ús: python3 genera_joc.py dades.json eixida.html
"""
import json
import sys
from pathlib import Path

MODES = {"quiz": "preguntes", "memory": "parelles", "escape": "proves"}


def valida(d):
    errors = []
    mode = d.get("mode")
    if mode not in MODES:
        errors.append(f"mode ha de ser un de {list(MODES)}")
        return errors
    items = d.get(MODES[mode]) or []
    if not items:
        errors.append(f"falta la llista '{MODES[mode]}'")
    if mode == "quiz":
        for n, q in enumerate(items, 1):
            if len(q.get("opcions", [])) < 2:
                errors.append(f"pregunta {n}: calen almenys 2 opcions")
            c = q.get("correcta")
            if not isinstance(c, int) or not 0 <= c < len(q.get("opcions", [])):
                errors.append(f"pregunta {n}: 'correcta' ha de ser l'índex (0, 1, 2…) d'una opció")
    if mode == "memory":
        for n, p in enumerate(items, 1):
            if not (isinstance(p, list) and len(p) == 2):
                errors.append(f"parella {n}: ha de ser una llista de dos textos")
        if len(items) > 12:
            errors.append("memory: més de 12 parelles costa de vore en pantalla; reduïx-les")
    if mode == "escape":
        for n, p in enumerate(items, 1):
            if not p.get("enigma") or not p.get("resposta"):
                errors.append(f"prova {n}: calen 'enigma' i 'resposta'")
    return errors


def main():
    if len(sys.argv) != 3:
        sys.exit(__doc__)
    dades = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    errs = valida(dades)
    if errs:
        sys.exit("Errors en les dades:\n- " + "\n- ".join(errs))
    plantilla = Path(__file__).resolve().parent.parent / "assets" / "plantilla-joc.html"
    html = plantilla.read_text(encoding="utf-8")
    html = html.replace("__DADES_JSON__", json.dumps(dades, ensure_ascii=False).replace("</", "<\\/"))
    html = html.replace("__TITOL__", dades.get("titol", "Joc"))
    html = html.replace('<html lang="ca">', f'<html lang="{dades.get("llengua", "ca")}">')
    Path(sys.argv[2]).write_text(html, encoding="utf-8")
    print(f"Fet: {sys.argv[2]}")


if __name__ == "__main__":
    main()
