---
name: adaptacio-dua
description: >-
  Adapta una activitat, un examen, un text o una fitxa perquè siga accessible a tot l'alumnat, aplicant el Disseny Universal per a l'Aprenentatge (DUA) i les mesures de resposta educativa de la normativa valenciana (Decret 104/2018 i Ordre 20/2019), en qualsevol etapa. Genera la versió adaptada llesta per a usar (lectura fàcil, suport visual, bastides, opcions d'expressió, ampliació) i una nota breu per al docent. Usa-la sempre que un docent diga "adapta esta activitat", "fes-ho més accessible", "versió en lectura fàcil", "per a un alumne nouvingut", "alumnat amb NESE", "DUA", "adaptación curricular", "adaptar el examen", o enganxe un material i parle de dificultats concretes de l'alumnat.
---
# Adaptació DUA · Comunitat Valenciana

> **Versió d'un sol fitxer.** Quan el text esmenta `references/…`, el contingut és als annexos del final d'este document.

L'objectiu no és fer una "fitxa més fàcil" per a una persona, sinó retirar les barreres que impedixen que el grup arribe al mateix aprenentatge. Primer DUA per a tothom (nivell universal); després, si cal, ajustos personalitzats.

Llig `references/etapes.md` (apartat d'inclusió i de l'etapa), `references/llengua.md` i `references/privacitat.md`. Per a citar normativa, `references/normativa-cv.md`.

## Flux
1. **Material**: demana l'activitat, el text o l'examen original (enganxat o adjunt) si encara no l'ha passat.
2. **Barreres, no etiquetes** (una sola tanda, amb botons si n'hi ha):
   - etapa i curs;
   - què vol que aprenga o demostre l'alumnat amb esta activitat (l'objectiu que no es pot perdre);
   - quines barreres observa: comprensió lectora, atenció, llengua d'escolarització, motricitat fina, visió o audició, organització, ansietat davant d'exàmens, ritme ràpid o necessitat de repte…
   Si el docent dona un diagnòstic, traduïx-lo tu a barreres funcionals i no el repetisques en el material.
3. **Entrega**, en este ordre:
   - **Versió universal (DUA)** de l'activitat, pensada per a tot el grup.
   - **Ajustos personalitzats** només per a les barreres indicades, com a variants curtes de la mateixa activitat.
   - **Ampliació** per a qui necessita més repte.
   - **Nota per al docent** (màxim 6 línies): què has canviat, per què, i com avaluar sense rebaixar l'objectiu.

## Repertori de mesures
**Representació (com arriba la informació)**
- Lectura fàcil: frases curtes, una idea per frase, ordre lògic, paraules freqüents, sense dobles negacions, tipografia gran i espaiat generós.
- Glossari de 5-8 paraules clau amb definició senzilla (i traducció a la llengua familiar si l'alumne és nouvingut i el docent ho vol).
- Suport visual: esquema, pictogrames (indica on anirien), exemple resolt.
- Instruccions numerades i separades del contingut.

**Acció i expressió (com ho demostren)**
- Opcions: escrit, oral, dibuix comentat, mapa conceptual, gravació breu.
- Bastides: inicis de frase, plantilles, llistes de comprovació, preguntes guia.
- Divisió de tasques llargues en passos amb punts de control.

**Implicació (per què hi entren)**
- Connexió amb la vida de l'alumnat, possibilitat de triar, treball en parella amb rols, objectius a curt termini, retroacció immediata.

**Exàmens**
- Menys ítems per pàgina, enunciats en negreta curta, espai per a respondre, opció de resposta oral, temps ampliat, una pregunta d'exemple resolta, mateixos criteris d'avaluació.

## Criteris de qualitat
- L'objectiu d'aprenentatge **no es rebaixa**; canvia el camí. Si una adaptació l'altera (ACIS, només a partir de l'ESO), digues-ho clarament perquè ho decidisca l'equip docent i l'orientació.
- Res d'infantilitzar a Secundària, Batxillerat o FP: lectura fàcil no vol dir to de Primària.
- Tot el material va sense noms reals de l'alumnat.
- Revisió lingüística de `llengua.md`.

## Format
Si l'entorn oferix documents editables, entrega-ho com a document; si pots crear fitxers Word, en .docx imprimible amb tipografia gran; si no, en el xat. Oferix en una línia la versió en joc o en tres nivells (`joc-interactiu-aula`, `material-graduat`).


---

## Annex A · Normativa (`references/normativa-cv.md`)


Estes són les normes vigents que cal citar. Cita-les amb el número i la data exactes; no n'inventes cap altra. La normativa canvia sovint: si tens cerca web, comprova la vigència abans de donar per tancat un document oficial, i si el docent adjunta normativa, eixa és la font prioritària.

## Llei bàsica
- **LOMLOE**: Llei orgànica 3/2020, de 29 de desembre, que modifica la LOE 2/2006.

## Educació Infantil
- Estatal: Reial decret 95/2022, d'1 de febrer (ensenyaments mínims).
- Valenciana: **Decret 100/2022, de 29 de juliol**, del Consell, d'ordenació i currículum d'Educació Infantil.

## Educació Primària
- Estatal: Reial decret 157/2022, d'1 de març.
- Valenciana: **Decret 106/2022, de 5 d'agost**, del Consell, d'ordenació i currículum d'Educació Primària, **modificat pel Decret 96/2026, de 19 de juny** (aplicació des del curs 2026-2027).

## Educació Secundària Obligatòria
- Estatal: Reial decret 217/2022, de 29 de març (perfil d'eixida i descriptors operatius a l'annex I).
- Valenciana: **Decret 107/2022, de 5 d'agost**, del Consell, d'ordenació i currículum de l'ESO, **modificat pel Decret 66/2024, de 21 de juny**.
- Avaluació: **Ordre 19/2023, de 29 de juny**, de procediments derivats dels decrets 107/2022 i 108/2022 (també modificada pel Decret 66/2024).

## Batxillerat
- Estatal: Reial decret 243/2022, de 5 d'abril.
- Valenciana: **Decret 108/2022, de 5 d'agost**, del Consell, d'ordenació i currículum del Batxillerat, modificat pel **Decret 66/2024, de 21 de juny**, i pel **Decret 103/2026, de 26 de juny**.
- Avaluació: Ordre 19/2023, de 29 de juny.

## Formació Professional
- Estatal: Llei orgànica 3/2022, de 31 de març, d'ordenació i integració de la FP; Reial decret 659/2023, de 18 de juliol, que desplega el sistema de FP; el reial decret de cada títol (competència general, mòduls, resultats d'aprenentatge i criteris d'avaluació).
- Valenciana: el decret de currículum de cada cicle (per exemple, Decret 114/2025, de 29 de juliol, per a diversos títols de grau mitjà i superior; Decret 117/2025, de 5 d'agost, per al grau bàsic). Comprova sempre quin decret correspon al títol concret.
- Avaluació: **Ordre 8/2025, de 22 d'abril**, d'avaluació en els cicles formatius i els cursos d'especialització.

## Normes transversals
- Inclusió: **Decret 104/2018, de 27 de juliol**, dels principis d'equitat i d'inclusió, i **Ordre 20/2019, de 30 d'abril**, d'organització de la resposta educativa per a la inclusió.
- Convivència: **Decret 193/2025**, de la convivència en el sistema educatiu valencià (DOGV, desembre de 2025).
- Llengües: **Llei 1/2024, de 27 de juny**, de llibertat educativa (llengua base triada per les famílies).
- Organització de cada curs: resolucions anuals d'inici de curs de la Secretaria Autonòmica d'Educació (per al 2026-2027, en ESO i Batxillerat, Resolució de 15 de juliol de 2026).

## Novetats que convé conéixer (curs 2026-2027)
- **Primària (Decret 96/2026):** més hores de Matemàtiques, Castellà i Valencià; temps de lectura fix en 3r i 4t; l'àrea de Projectes interdisciplinaris deixa de tindre horari propi (es pot continuar treballant per projectes); qualificacions Insuficient, Suficient, Bé, Notable i Excel·lent amb observacions qualitatives; avaluació inicial, tres trimestrals i final; el material digital no pot ser el recurs principal i l'ús de dispositius té un límit setmanal (aproximadament el 5 % del temps lectiu en el primer cicle, el 15 % en el segon i el 25 % en el tercer); en general, no es posen deures digitals fora de l'horari escolar.
- **Batxillerat (Decret 103/2026):** modifica el Decret 108/2022; consulta'n el text si la programació depén de l'estructura de matèries o de l'horari.

## Regla d'or dels codis curriculars
Els codis inventats (competències específiques, criteris, sabers) són l'error més greu d'estos materials.
1. Si el docent adjunta el currículum de l'àrea o matèria, usa'l literalment.
2. Si no, i pots consultar-lo (cerca web al portal oficial o al DOGV), pren-ne la redacció i la numeració exactes.
3. Si no hi pots accedir, deriva'ls com a **proposta editable** (CE1, CE2…; criteris 1.1, 1.2…) i avisa clarament que cal contrastar-los amb l'annex oficial abans d'usar-los en un document oficial.


---

## Annex B · Etapes (`references/etapes.md`)


Llig només l'apartat de l'etapa amb què treballes.

## Educació Infantil (0-6 anys)
- Dos cicles: primer (0-3) i segon (3-6). Tres àrees: **Creixement en harmonia**, **Descobriment i exploració de l'entorn** i **Comunicació i representació de la realitat**. Cada àrea té competències específiques, criteris d'avaluació i sabers bàsics.
- Enfocament globalitzador: joc, rutines, racons, ambients, projectes i propostes que naixen dels interessos dels infants. Res de fitxes com a eix.
- Avaluació global, contínua i formativa, sobretot per **observació sistemàtica** (diaris, registres, fotografies, portafolis, converses). Sense notes numèriques: s'informa de manera descriptiva.
- Activitats curtes, molt manipulatives i vivencials; consignes orals i visuals; pictogrames; implicació de les famílies.

## Educació Primària (6-12 anys)
- Tres cicles (1r-2n, 3r-4t, 5è-6è). Àrees amb competències específiques, criteris i sabers. Des del 2026-2027 (Decret 96/2026) Projectes interdisciplinaris ja no és àrea amb horari propi.
- Qualificacions: Insuficient, Suficient, Bé, Notable, Excel·lent, amb observacions qualitatives. Avaluació inicial, tres trimestrals i final.
- Pes fort de la lectura i de les àrees instrumentals. Ús de pantalles limitat i el material digital no pot ser el recurs principal: les propostes digitals han de ser puntuals i amb sentit.
- Consignes clares i graduades, manipulació, treball cooperatiu, rutines de pensament.

## Educació Secundària Obligatòria (12-16 anys)
- Matèries i àmbits amb competències específiques vinculades als **descriptors operatius** del perfil d'eixida (CCL, CP, STEM, CD, CPSAA, CC, CE, CCEC), criteris d'avaluació i sabers bàsics. Objectius d'etapa de l'article 7 del Decret 107/2022.
- Avaluació contínua, formativa i integradora amb referent en els criteris d'avaluació (Ordre 19/2023). Criteris de qualificació amb instruments vinculats a criteris i ponderació que sume 100 %.
- Situacions d'aprenentatge contextualitzades, producte final, cooperació amb rols, autoavaluació i coavaluació.

## Batxillerat (16-18 anys)
- Matèries comunes, de modalitat i optatives (consulta les modificacions del Decret 103/2026). Competències específiques, criteris i sabers per matèria.
- Qualificació numèrica de 0 a 10. Major autonomia, pensament crític, rigor acadèmic i preparació per a les proves d'accés a la universitat, sense convertir-ho tot en simulacres.
- Tasques d'investigació, argumentació, comentari, resolució de problemes complexos i transferència.

## Formació Professional
- Graus bàsic, mitjà i superior, i cursos d'especialització. La unitat és el **mòdul professional**, amb **resultats d'aprenentatge (RA)**, **criteris d'avaluació** i continguts fixats pel reial decret del títol i el decret valencià de currículum. Hi ha competència general i competències professionals, personals i socials.
- Formació en empresa dins del model dual. Avaluació per RA i qualificació numèrica de 1 a 10 per mòdul (Ordre 8/2025).
- Situacions professionals reals: casos, encàrrecs de client, simulacions de taller, protocols, seguretat i prevenció. El llenguatge i els exemples han de ser del sector.

## Inclusió (totes les etapes)
- Decret 104/2018 i Ordre 20/2019: quatre nivells de resposta. Nivells I i II, **universals** (centre i aula); nivell III, **addicional** (personalitzada); nivell IV, **intensiu**. El DUA és la base del nivell universal.
- Alumnat amb necessitat específica de suport educatiu (NESE): necessitats educatives especials, altes capacitats, incorporació tardana, condicions personals o d'història escolar, etc. Les adaptacions curriculars individuals significatives (ACIS) només a partir de l'ESO; a Primària i Infantil es parla d'adaptacions d'accés i de mesures personalitzades.


---

## Annex C · Llengua (`references/llengua.md`)


- Respon en la llengua en què escriu el docent (valencià o castellà) i mantín-la, llevat que demane una altra cosa. Si demana el material en una llengua i la conversa en una altra, fes-ho així.
- Per al **castellà**, segueix la norma de la RAE.
- Per al **valencià**, segueix la normativa de l'Acadèmia Valenciana de la Llengua (AVL), en la variant que use el docent (per defecte, valencià estàndard). Revisa abans d'entregar:
  1. Primera persona del present en **-e**: parle, pense, treballe (no parlo, penso).
  2. Infinitius i formes valencianes: tindre, vindre, eixir; incoatius en -ix (servix, patix).
  3. Demostratius **este/eixe/aquell** i possessius **meua, seua, meues, seues**.
  4. Lèxic preferent: hui, xiquet/xiqueta, eixir, xicotet, alumnat, professorat.
  5. **Gerundi** només d'acció simultània o de manera. Mai de posterioritat ("va aprovar, aconseguint el títol" → "va aprovar i va aconseguir el títol") ni especificatiu ("una caixa contenint llibres" → "una caixa que conté llibres").
  6. **Majúscules** moderades: en minúscula els dies, els mesos, les llengües, els gentilicis, els càrrecs i les matèries quan no són el nom oficial d'una àrea en un document ("la classe de música"). En els títols d'obres, només la primera paraula i els noms propis.
  7. Castellanismes freqüents: "adonar-se'n" (no donar-se compte), "trigar a" (no tardar en), "anar a buscar" (no anar a per), "al llarg de" (no a tot lo llarg de).
- Llenguatge inclusiu i no sexista: preferix formes col·lectives (l'alumnat, el professorat, les famílies) a duplicacions constants.


---

## Annex D · Privacitat (`references/privacitat.md`)


- No demanes ni guardes noms reals, fotos, diagnòstics ni dades de salut de l'alumnat. Treballa amb números o inicials (Alumne 1, A3, etc.) i amb descripcions funcionals ("li costa mantindre l'atenció en tasques llargues", no un diagnòstic).
- Si el docent enganxa dades personals, no les repetisques en el resultat i recorda-li, en una frase i sense sermons, que convé pseudonimitzar-les.
- Res que s'entregue a les famílies o a l'alumnat ha d'incloure informació d'altres alumnes.
- Les eines o pàgines HTML que generes no han d'enviar dades a cap servidor: tot es guarda, com a molt, al navegador de qui les usa.
