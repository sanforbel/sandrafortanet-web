---
name: material-graduat
description: >-
  A partir d'un tema, un text o una activitat, genera la mateixa tasca en tres nivells de dificultat (bàsic, estàndard i repte) perquè tot l'alumnat d'una aula heterogènia treballe el mateix aprenentatge al seu ritme, en qualsevol etapa i àrea, amb solucionari per al docent. Usa-la sempre que un docent diga "fes-ho en tres nivells", "activitat multinivell", "per a una classe molt diversa", "graduar la dificultat", "ficha por niveles", "reforç i ampliació", o demane exercicis per a un grup on uns van molt per davant i altres necessiten suport.
---

# Material graduat en tres nivells

La clau és que els tres nivells treballen **el mateix criteri d'avaluació** i acaben en la mateixa posada en comú. El que canvia és el suport, la complexitat i l'autonomia, no el tema. Així ningú no queda fora de la conversa de classe.

Llig l'apartat de l'etapa de `references/etapes.md`, `references/llengua.md` i `references/privacitat.md`.

## Flux
1. Recull (una sola tanda, amb botons si n'hi ha): etapa i curs, àrea, tema o material de partida, què ha d'aprendre tothom (el criteri o objectiu), temps disponible, i si ho vol imprimible o per a pantalla.
2. Proposa en dos línies el nucli comú i la idea de cada nivell. Si el docent ja ha donat tota la informació, passa directament a generar-lo.
3. Genera el material.

## Com es gradua
| Nivell | Per a qui | Què canvia |
|---|---|---|
| **Bàsic** (símbol: llavor) | qui necessita més suport | text o dades més curts, vocabulari clau explicat, exemple resolt, bastides (inicis de frase, opcions per a triar), passos guiats |
| **Estàndard** (símbol: brot) | la majoria | tasca completa amb pautes generals, alguna pregunta inferencial |
| **Repte** (símbol: arbre) | qui va més de pressa | menys guia, més transferència: aplicar a un cas nou, argumentar, crear, connectar amb un altre tema |

Usa símbols neutres i no números de "llest" o "lent": l'alumnat ha de poder canviar de nivell sense estigma, i el docent pot deixar que cadascú trie i després pujar de nivell.

## Estructura de l'entrega
1. **Capçalera comuna**: títol, objectiu en llenguatge de l'alumnat ("Hui aprendrem a…") i consigna general.
2. **Els tres nivells**, cadascun en una pàgina o bloc separat, amb la mateixa estructura visual.
3. **Posada en comú**: una activitat final que reunix tots els nivells (cada grup aporta una part, debat, mural).
4. **Solucionari i pistes per al docent**: respostes, errors freqüents i com fer pujar de nivell.

## Adaptació a l'etapa
- **Infantil**: tres versions d'una mateixa proposta manipulativa o de joc, amb consignes orals i pictogrames; sense fitxes llargues.
- **Primària**: molta lectura i manipulació; tipografia gran en el nivell bàsic.
- **ESO i Batxillerat**: el nivell repte ha de ser de veres més exigent (anàlisi, crítica, creació), no simplement més llarg.
- **FP**: casos del sector amb tres graus d'autonomia (guiat pas a pas, amb protocol, encàrrec obert de client).

## Comprovació
- Els tres nivells avaluen el mateix criteri.
- El nivell repte no és "més exercicis del mateix".
- El bàsic no infantilitza.
- Revisió lingüística.

## Format
Document editable si l'entorn l'oferix; si no, .docx imprimible si pots crear fitxers Word; si no, en el xat. Oferix en una línia convertir-ho en joc (`joc-interactiu-aula`).
