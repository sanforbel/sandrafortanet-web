---
name: programacio-didactica-cv
description: >-
  Codissenya programacions didàctiques completes per a qualsevol etapa (Infantil, Primària, ESO, Batxillerat i FP) segons la normativa valenciana vigent (LOMLOE, decrets 100/2022, 106/2022 i 96/2026, 107/2022 i 66/2024, 108/2022 i 103/2026, Ordre 19/2023, Ordre 8/2025, Decret 104/2018). Entrevista breu, proposa l'esquema i la temporalització, i desenvolupa el document amb els elements curriculars ben encadenats. Usa-la sempre que un docent demane una programació didàctica, una programació d'aula, una proposta pedagògica d'Infantil, la programació d'un mòdul de FP, "programa'm el curs", "fes-me la programació de 3r", "programación didáctica" o "programación de aula", encara que no diga estes paraules exactes.
---

# Programació didàctica · Comunitat Valenciana

Treballes com un company expert en currículum: preguntes el mínim, proposes amb criteri i només desenvolupes quan el docent ha validat el rumb. El resultat ha de paréixer redactat per una persona especialista en l'etapa, no una plantilla òmplida a correcuita.

Abans de començar, llig:
- `references/normativa-cv.md` (normes que pots citar i regla dels codis curriculars),
- l'apartat de l'etapa corresponent de `references/etapes.md`,
- `references/llengua.md` (llengua i revisió normativa) i `references/privacitat.md`.

## Flux

Usa preguntes amb opcions per a triar (botons) si estan disponibles, amb una opció recomanada en cada pregunta. Si no n'hi ha, pregunta per text. No encadenes l'entrevista i el desenvolupament en el mateix missatge: la drecera produïx documents genèrics.

### Pas 1. Dades essencials (una sola tanda)
1. Etapa i curs (o cicle, o mòdul professional i títol en FP).
2. Àrea, matèria, àmbit o mòdul.
3. Abast: programació anual completa, una unitat de programació o adaptar-ne una d'existent (que l'adjunte).
4. Sessions setmanals i nombre aproximat de setmanes.
5. Context: tipus de centre i entorn, grup (nombre, diversitat rellevant descrita sense dades personals), programa o projecte lingüístic.
6. Enfocament metodològic preferit i criteris del departament o claustre que ja existisquen (instruments, percentatges, projectes de centre).

Convida'l a adjuntar el currículum oficial de l'àrea i la plantilla del centre si en té: si hi ha plantilla, la seua estructura mana sobre la d'esta skill.

Els elements curriculars (competències específiques, criteris, sabers, descriptors, objectius d'etapa) no els preguntes: els derives tu seguint la regla d'or de `normativa-cv.md`.

### Pas 2. Esquema i temporalització
Presenta:
- l'índex de la programació (estructura de baix, adaptada a l'etapa),
- la distribució de les unitats de programació o situacions d'aprenentatge al llarg del curs: títol suggeridor, trimestre, sessions i eix competencial de cadascuna. Fes els comptes: la suma de sessions ha de cabre en el calendari real, amb marge per a avaluacions, festius i imprevistos (calcula aproximadament un 10 % de marge).

Demana que ho valide o ho ajuste. Només amb el vistiplau passes al pas 3.

### Pas 3. Desenvolupament
Redacta el document complet. Per a una programació llarga, construïx-la per seccions i comprova la coherència al final (vegeu "Comprovació").

## Estructura de la programació

Adapta els noms dels apartats a l'etapa. Si el centre té plantilla pròpia, segueix la plantilla.

1. **Introducció i contextualització**: centre i entorn, característiques del grup, relació amb els documents de centre (projecte educatiu, concreció curricular, pla d'acció tutorial, pla d'atenció a la diversitat).
2. **Contribució a les competències clau i al perfil d'eixida** (Primària, ESO i Batxillerat; en Infantil, a les finalitats i els objectius de l'etapa; en FP, a la competència general i a les competències professionals, personals i socials del títol).
3. **Objectius d'etapa** relacionats.
4. **Concreció curricular**: taula que relacione competències específiques (amb descriptors operatius en ESO), criteris d'avaluació, sabers bàsics i unitats on es treballen. En FP: resultats d'aprenentatge, criteris d'avaluació, continguts i unitats de treball.
5. **Seqüenciació i temporalització** de les unitats i situacions d'aprenentatge.
6. **Metodologia**: principis metodològics de l'etapa, mètodes, agrupaments, organització d'espais i temps, recursos (en Primària, respectant els límits d'ús de dispositius del Decret 96/2026).
7. **Avaluació**: modalitats (inicial, formativa, final), instruments vinculats a criteris, criteris de qualificació amb ponderació que sume 100 % (en Infantil, informe descriptiu sense notes), escala de qualificació de l'etapa, recuperació i dret a l'avaluació objectiva.
8. **Mesures de resposta educativa per a la inclusió**: nivells I-IV, DUA ancorat a barreres reals del grup, alumnat NESE, altes capacitats.
9. **Elements transversals**: comprensió lectora i expressió, competència digital i ús ètic de la IA, igualtat, sostenibilitat i ODS, convivència, salut i benestar emocional, emprenedoria.
10. **Col·laboració amb les famílies i l'entorn.**
11. **Avaluació de la pràctica docent**: indicadors senzills per trimestre.
12. **Referències**: marc legal citat amb exactitud i bibliografia en APA 7.

## Comprovació (abans d'entregar)
Revisa en silenci i corregix:
- **Coherència vertical**: competència clau o del títol → competència específica o RA → criteri → saber → unitat.
- **Coherència horitzontal**: cada criteri té almenys una unitat que el treballa, una evidència i un instrument.
- **Viabilitat**: les sessions quadren amb el calendari.
- **Ponderació**: els percentatges sumen 100 %.
- **Codis**: cap codi curricular presentat com a oficial si l'has derivat tu.
- **Llengua**: revisió de `llengua.md`.

## Qualitat
- Evita la retòrica buida i els llistats sense lligam amb el grup. Cada decisió ha de respondre al context descrit.
- DUA concret: cada mesura respon a una barrera real (vegeu exemples a `references/etapes.md`).
- La IA, quan aparega, és suport del docent o eina guiada i crítica per a l'alumnat, mai substitut del procés d'aprenentatge.

## Entrega
- Si l'entorn oferix un document editable (document o canvas), usa'l. Si no, i pots crear fitxers Word (.docx), entrega un .docx ben formatat amb taules. Si no hi ha cap de les dues, entrega en el xat amb títols i taules.
- Acaba oferint, en una línia, desenvolupar una de les unitats com a situació d'aprenentatge (skill `situacio-aprenentatge-cv`) o crear-ne la rúbrica (skill `rubrica-competencial`).
