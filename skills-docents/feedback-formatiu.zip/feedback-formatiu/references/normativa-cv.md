# Marc normatiu valencià (revisat el novembre de 2026)

Estes són les normes vigents que cal citar. Cita-les amb el número i la data exactes; no n'inventes cap altra. La normativa canvia sovint: si tens cerca web, comprova la vigència abans de donar per tancat un document oficial, i si el docent adjunta normativa, eixa és la font prioritària.

## Llei bàsica
- **LOMLOE**: Llei orgànica 3/2020, de 29 de desembre, que modifica la LOE 2/2006.

## Educació Infantil
- Estatal: Reial decret 95/2022, d'1 de febrer (ensenyaments mínims).
- Valenciana: **Decret 100/2022, de 29 de juliol**, del Consell, d'ordenació i currículum d'Educació Infantil.

## Educació Primària
- Estatal: Reial decret 157/2022, d'1 de març.
- Valenciana: **Decret 106/2022, de 5 d'agost**, del Consell, d'ordenació i currículum d'Educació Primària, **modificat pel Decret 96/2026, de 19 de juny** (aplicació des del curs 2026-2027).

## Educació Secundària Obligatòria
- Estatal: Reial decret 217/2022, de 29 de març (perfil d'eixida i descriptors operatius a l'annex I).
- Valenciana: **Decret 107/2022, de 5 d'agost**, del Consell, d'ordenació i currículum de l'ESO, **modificat pel Decret 66/2024, de 21 de juny**.
- Avaluació: **Ordre 19/2023, de 29 de juny**, de procediments derivats dels decrets 107/2022 i 108/2022 (també modificada pel Decret 66/2024).

## Batxillerat
- Estatal: Reial decret 243/2022, de 5 d'abril.
- Valenciana: **Decret 108/2022, de 5 d'agost**, del Consell, d'ordenació i currículum del Batxillerat, modificat pel **Decret 66/2024, de 21 de juny**, i pel **Decret 103/2026, de 26 de juny**.
- Avaluació: Ordre 19/2023, de 29 de juny.

## Formació Professional
- Estatal: Llei orgànica 3/2022, de 31 de març, d'ordenació i integració de la FP; Reial decret 659/2023, de 18 de juliol, que desplega el sistema de FP; el reial decret de cada títol (competència general, mòduls, resultats d'aprenentatge i criteris d'avaluació).
- Valenciana: el decret de currículum de cada cicle (per exemple, Decret 114/2025, de 29 de juliol, per a diversos títols de grau mitjà i superior; Decret 117/2025, de 5 d'agost, per al grau bàsic). Comprova sempre quin decret correspon al títol concret.
- Avaluació: **Ordre 8/2025, de 22 d'abril**, d'avaluació en els cicles formatius i els cursos d'especialització.

## Normes transversals
- Inclusió: **Decret 104/2018, de 27 de juliol**, dels principis d'equitat i d'inclusió, i **Ordre 20/2019, de 30 d'abril**, d'organització de la resposta educativa per a la inclusió.
- Convivència: **Decret 193/2025**, de la convivència en el sistema educatiu valencià (DOGV, desembre de 2025).
- Llengües: **Llei 1/2024, de 27 de juny**, de llibertat educativa (llengua base triada per les famílies).
- Organització de cada curs: resolucions anuals d'inici de curs de la Secretaria Autonòmica d'Educació (per al 2026-2027, en ESO i Batxillerat, Resolució de 15 de juliol de 2026).

## Novetats que convé conéixer (curs 2026-2027)
- **Primària (Decret 96/2026):** més hores de Matemàtiques, Castellà i Valencià; temps de lectura fix en 3r i 4t; l'àrea de Projectes interdisciplinaris deixa de tindre horari propi (es pot continuar treballant per projectes); qualificacions Insuficient, Suficient, Bé, Notable i Excel·lent amb observacions qualitatives; avaluació inicial, tres trimestrals i final; el material digital no pot ser el recurs principal i l'ús de dispositius té un límit setmanal (aproximadament el 5 % del temps lectiu en el primer cicle, el 15 % en el segon i el 25 % en el tercer); en general, no es posen deures digitals fora de l'horari escolar.
- **Batxillerat (Decret 103/2026):** modifica el Decret 108/2022; consulta'n el text si la programació depén de l'estructura de matèries o de l'horari.

## Regla d'or dels codis curriculars
Els codis inventats (competències específiques, criteris, sabers) són l'error més greu d'estos materials.
1. Si el docent adjunta el currículum de l'àrea o matèria, usa'l literalment.
2. Si no, i pots consultar-lo (cerca web al portal oficial o al DOGV), pren-ne la redacció i la numeració exactes.
3. Si no hi pots accedir, deriva'ls com a **proposta editable** (CE1, CE2…; criteris 1.1, 1.2…) i avisa clarament que cal contrastar-los amb l'annex oficial abans d'usar-los en un document oficial.
