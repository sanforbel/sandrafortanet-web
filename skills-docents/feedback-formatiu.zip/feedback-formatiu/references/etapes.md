# Com és cada etapa (per a adaptar-hi el material)

Llig només l'apartat de l'etapa amb què treballes.

## Educació Infantil (0-6 anys)
- Dos cicles: primer (0-3) i segon (3-6). Tres àrees: **Creixement en harmonia**, **Descobriment i exploració de l'entorn** i **Comunicació i representació de la realitat**. Cada àrea té competències específiques, criteris d'avaluació i sabers bàsics.
- Enfocament globalitzador: joc, rutines, racons, ambients, projectes i propostes que naixen dels interessos dels infants. Res de fitxes com a eix.
- Avaluació global, contínua i formativa, sobretot per **observació sistemàtica** (diaris, registres, fotografies, portafolis, converses). Sense notes numèriques: s'informa de manera descriptiva.
- Activitats curtes, molt manipulatives i vivencials; consignes orals i visuals; pictogrames; implicació de les famílies.

## Educació Primària (6-12 anys)
- Tres cicles (1r-2n, 3r-4t, 5è-6è). Àrees amb competències específiques, criteris i sabers. Des del 2026-2027 (Decret 96/2026) Projectes interdisciplinaris ja no és àrea amb horari propi.
- Qualificacions: Insuficient, Suficient, Bé, Notable, Excel·lent, amb observacions qualitatives. Avaluació inicial, tres trimestrals i final.
- Pes fort de la lectura i de les àrees instrumentals. Ús de pantalles limitat i el material digital no pot ser el recurs principal: les propostes digitals han de ser puntuals i amb sentit.
- Consignes clares i graduades, manipulació, treball cooperatiu, rutines de pensament.

## Educació Secundària Obligatòria (12-16 anys)
- Matèries i àmbits amb competències específiques vinculades als **descriptors operatius** del perfil d'eixida (CCL, CP, STEM, CD, CPSAA, CC, CE, CCEC), criteris d'avaluació i sabers bàsics. Objectius d'etapa de l'article 7 del Decret 107/2022.
- Avaluació contínua, formativa i integradora amb referent en els criteris d'avaluació (Ordre 19/2023). Criteris de qualificació amb instruments vinculats a criteris i ponderació que sume 100 %.
- Situacions d'aprenentatge contextualitzades, producte final, cooperació amb rols, autoavaluació i coavaluació.

## Batxillerat (16-18 anys)
- Matèries comunes, de modalitat i optatives (consulta les modificacions del Decret 103/2026). Competències específiques, criteris i sabers per matèria.
- Qualificació numèrica de 0 a 10. Major autonomia, pensament crític, rigor acadèmic i preparació per a les proves d'accés a la universitat, sense convertir-ho tot en simulacres.
- Tasques d'investigació, argumentació, comentari, resolució de problemes complexos i transferència.

## Formació Professional
- Graus bàsic, mitjà i superior, i cursos d'especialització. La unitat és el **mòdul professional**, amb **resultats d'aprenentatge (RA)**, **criteris d'avaluació** i continguts fixats pel reial decret del títol i el decret valencià de currículum. Hi ha competència general i competències professionals, personals i socials.
- Formació en empresa dins del model dual. Avaluació per RA i qualificació numèrica de 1 a 10 per mòdul (Ordre 8/2025).
- Situacions professionals reals: casos, encàrrecs de client, simulacions de taller, protocols, seguretat i prevenció. El llenguatge i els exemples han de ser del sector.

## Inclusió (totes les etapes)
- Decret 104/2018 i Ordre 20/2019: quatre nivells de resposta. Nivells I i II, **universals** (centre i aula); nivell III, **addicional** (personalitzada); nivell IV, **intensiu**. El DUA és la base del nivell universal.
- Alumnat amb necessitat específica de suport educatiu (NESE): necessitats educatives especials, altes capacitats, incorporació tardana, condicions personals o d'història escolar, etc. Les adaptacions curriculars individuals significatives (ACIS) només a partir de l'ESO; a Primària i Infantil es parla d'adaptacions d'accés i de mesures personalitzades.
