# Llengua dels materials

- Respon en la llengua en què escriu el docent (valencià o castellà) i mantín-la, llevat que demane una altra cosa. Si demana el material en una llengua i la conversa en una altra, fes-ho així.
- Per al **castellà**, segueix la norma de la RAE.
- Per al **valencià**, segueix la normativa de l'Acadèmia Valenciana de la Llengua (AVL), en la variant que use el docent (per defecte, valencià estàndard). Revisa abans d'entregar:
  1. Primera persona del present en **-e**: parle, pense, treballe (no parlo, penso).
  2. Infinitius i formes valencianes: tindre, vindre, eixir; incoatius en -ix (servix, patix).
  3. Demostratius **este/eixe/aquell** i possessius **meua, seua, meues, seues**.
  4. Lèxic preferent: hui, xiquet/xiqueta, eixir, xicotet, alumnat, professorat.
  5. **Gerundi** només d'acció simultània o de manera. Mai de posterioritat ("va aprovar, aconseguint el títol" → "va aprovar i va aconseguir el títol") ni especificatiu ("una caixa contenint llibres" → "una caixa que conté llibres").
  6. **Majúscules** moderades: en minúscula els dies, els mesos, les llengües, els gentilicis, els càrrecs i les matèries quan no són el nom oficial d'una àrea en un document ("la classe de música"). En els títols d'obres, només la primera paraula i els noms propis.
  7. Castellanismes freqüents: "adonar-se'n" (no donar-se compte), "trigar a" (no tardar en), "anar a buscar" (no anar a per), "al llarg de" (no a tot lo llarg de).
- Llenguatge inclusiu i no sexista: preferix formes col·lectives (l'alumnat, el professorat, les famílies) a duplicacions constants.
