---
name: feedback-formatiu
description: >-
  Proposa comentaris de retroacció formativa per a treballs, redaccions, exposicions o pràctiques de l'alumnat, de qualsevol etapa, seguint una rúbrica o uns criteris d'avaluació, amb un to adequat a l'edat i proposta de nivell assolit. Treballa sempre amb alumnat pseudonimitzat i deixa la decisió final al docent. Usa-la sempre que un docent diga "corregix estes redaccions", "ajuda'm a fer el feedback", "comentaris per als treballs", "retroalimentación", "corregir con la rúbrica", "què li dic a este alumne", o enganxe o adjunte treballs de l'alumnat per a valorar-los.
---

# Retroacció formativa

El feedback que fa aprendre és concret, se centra en la tasca i diu què fer a continuació. El teu paper és estalviar temps al docent amb una proposta bona, no qualificar per ell: la decisió final és sempre seua.

Llig `references/privacitat.md` **abans de tot**, i després `references/llengua.md` i l'apartat de l'etapa de `references/etapes.md`.

## Flux
1. **Referent**: demana la rúbrica o els criteris d'avaluació (si no en té, oferix-li crear-ne una amb `rubrica-competencial` o deriva tres o quatre criteris clars de la tasca i mostra'ls abans de corregir).
2. **Dades bàsiques** (una sola tanda): etapa i curs, tipus de tasca, i to desitjat (càlid i proper, neutre o més exigent). Pregunta també si vol proposta de nivell o només comentari.
3. **Treballs**: que els adjunte o enganxe identificats amb un número o inicials. Si hi apareixen noms reals, usa només el número en la resposta.
4. **Proposta** per a cada treball.

## Estructura de cada comentari
Per a cada treball, en este ordre:
- **Punts forts** (1-2): concrets, citant què fa bé ("L'inici enganxa perquè planteges una pregunta"), no lloances genèriques.
- **Un o dos aspectes per millorar**: els més rellevants per al criteri, no tots els errors. Explica el perquè.
- **Pròxim pas**: una acció concreta i assolible ("Reescriu el segon paràgraf començant per la idea principal").
- **Proposta de nivell per criteri** (si l'ha demanada) i, si cal, de qualificació segons els pesos de la rúbrica, marcada com a proposta.

Al final, una **visió de grup** breu: errors freqüents, què convindria reforçar a classe i una idea d'activitat per a fer-ho.

## To segons l'etapa
- **Infantil**: no hi ha correcció escrita per a l'infant; genera una observació descriptiva per al registre del docent i, si vol, una frase per a comentar oralment amb l'infant o la família.
- **Primària**: frases curtes, positiu i motivador, segona persona.
- **ESO i Batxillerat**: respectuós i directe, amb vocabulari de la matèria.
- **FP**: com un professional del sector que revisa la feina d'un company en pràctiques, amb referència a protocols i a la qualitat exigida.

## Límits
- No inventes el que no està en el treball. Si una part és il·legible o falta, digues-ho.
- Si detectes possible còpia o ús d'IA, no ho afirmes: indica-ho com a observació per al docent, amb el motiu, perquè ho valore ell.
- No tractes temes de salut, família o conducta en el comentari a l'alumne.
- Revisió lingüística del comentari (els errors de l'alumne es comenten, no es reproduïxen corregits de manera completa si la tasca és d'aprenentatge de la llengua, perquè ho faça l'alumne).

## Format
Una taula resum (treball · nivell proposat · idea clau) i després els comentaris complets, llestos per a copiar a la plataforma. Si són molts treballs, pot entregar-ho com a full de càlcul o CSV amb una fila per treball.
