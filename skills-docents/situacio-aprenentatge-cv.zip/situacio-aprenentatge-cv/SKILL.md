---
name: situacio-aprenentatge-cv
description: >-
  Dissenya situacions d'aprenentatge (SA) competencials per a qualsevol etapa (Infantil, Primària, ESO, Batxillerat i FP) segons el currículum valencià vigent. Fa una entrevista breu, proposa tres idees realment diferents perquè el docent en trie una i desenvolupa la SA completa amb seqüència per sessions, producte final, avaluació i mesures DUA. Usa-la sempre que un docent diga "fes-me una SA", "una situació d'aprenentatge", "una situación de aprendizaje", "un projecte per a la meua classe", "una seqüència didàctica", "una proposta per a Infantil", o porte una idea, un text, una notícia o una efemèride per a convertir-la en activitat competencial.
---

# Situació d'aprenentatge · Comunitat Valenciana

Una bona SA naix d'un repte amb sentit per a l'alumnat i acaba en un producte que algú pot vore, usar o escoltar. El teu treball és ajudar el docent a arribar-hi de pressa i amb rigor curricular.

Abans de començar, llig `references/normativa-cv.md`, l'apartat de l'etapa a `references/etapes.md`, `references/llengua.md` i `references/privacitat.md`.

## Flux
Usa botons de pregunta (AskUserQuestion) si estan disponibles, amb una opció recomanada. Atura't després de cada pas.

### Pas 1. Punt de partida i dades (una sola tanda)
1. Etapa i curs (o mòdul en FP).
2. Àrea, matèria o mòdul (i si vol que siga interdisciplinària, amb quines).
3. Des d'on partim: una idea pròpia, un text o recurs, un esdeveniment o efemèride, una unitat que ja té o el currículum.
4. Durada en sessions.
5. Trets del grup rellevants (sense dades personals).

Si el docent ja ho ha explicat tot en el primer missatge, no ho tornes a preguntar: confirma en una línia el que has entés i passa al pas 2.

### Pas 2. Tres propostes diferents
Presenta **tres** propostes que es diferencien de veres (repte, metodologia i producte final distints), de 4-5 línies cadascuna:
- títol suggeridor,
- repte o pregunta motriu,
- metodologia (projecte, cooperatiu, gamificació, aprenentatge servei, estudi de cas, taller…),
- producte final i destinatari real,
- per què pot enganxar este grup.

Demana que en trie una, que en combine dues o que en vulga tres de noves.

### Pas 3. Desenvolupament complet
Desenvolupa la proposta triada amb l'estructura següent.

## Estructura de la SA
1. **Identificació**: títol, etapa i curs, àrea o matèria, sessions i temporització, descripció breu, repte i producte final.
2. **Justificació i context**: per què esta SA té sentit per a este grup i este moment, i connexió amb l'entorn o amb els ODS quan siga natural.
3. **Elements curriculars**: competències específiques (amb descriptors operatius en ESO), criteris d'avaluació i sabers bàsics, o RA i criteris en FP. Segueix la regla d'or de `normativa-cv.md`.
4. **Metodologia i organització**: agrupaments, espais, rols cooperatius, recursos.
5. **Seqüència per sessions**: per a cada sessió, objectiu, activitats d'inici, desenvolupament i tancament, materials i evidència que genera. Recorre les fases d'activació, exploració, estructuració i aplicació o transferència.
6. **Avaluació**: avaluació inicial, formativa i final; taula criteri ↔ evidència ↔ instrument ↔ pes (suma 100 %); autoavaluació i coavaluació. En Infantil, observació sistemàtica i registre descriptiu, sense pesos ni notes.
7. **Mesures d'inclusió i DUA**: tres o quatre mesures concretes lligades a barreres reals del grup, i una ampliació per a qui avança més de pressa.
8. **Recursos i referències.**

## Adaptació a l'etapa (resum)
- **Infantil**: sessions curtes, joc i manipulació, rutines, assemblea, implicació de les famílies; el producte pot ser una exposició, un llibre col·lectiu o una festa.
- **Primària**: consignes graduades, molta lectura i oralitat; dispositius només puntualment i amb sentit.
- **ESO**: repte social o real, cooperació amb rols, producte públic.
- **Batxillerat**: investigació, argumentació i rigor, amb autonomia.
- **FP**: encàrrec professional realista, procediments i seguretat del sector, vincle amb l'empresa.

## Comprovació (abans d'entregar)
- Cada criteri té activitat, evidència i instrument, i tot conflueix en el producte final.
- Les sessions caben en el temps indicat (si no, retalla, no comprimisques).
- Els pesos sumen 100 % (excepte en Infantil).
- Cap codi curricular derivat presentat com a oficial.
- Revisió lingüística de `llengua.md`.

## Entrega
- Document editable si l'entorn l'oferix; si no, .docx amb la skill de Word si hi és; si no, en el xat amb taules.
- Al final, oferix en una línia la rúbrica del producte final (`rubrica-competencial`), la versió graduada d'alguna activitat (`material-graduat`) o un joc per a repassar (`joc-interactiu-aula`).
