---
name: rubrica-competencial
description: >-
  Crea rúbriques d'avaluació competencial vinculades als criteris d'avaluació del currículum valencià, per a qualsevol etapa, amb descriptors clars per nivells, pesos que sumen 100 % i versió per a l'alumnat (autoavaluació i coavaluació). També pot generar dianes, llistes de control i escales d'observació. Usa-la sempre que un docent diga "fes-me una rúbrica", "rúbrica per a avaluar…", "rúbrica de l'exposició oral", "llista de control", "diana d'autoavaluació", "escala d'observació per a Infantil", "rúbrica para evaluar", o necessite avaluar un producte o una tasca de manera objectiva.
---

# Rúbrica competencial

Una rúbrica útil fa dues coses: permet al docent qualificar de manera justa i ràpida, i diu a l'alumnat, abans de començar, com és una faena ben feta. Per això sempre n'hi ha dues versions: la del docent i la de l'alumnat.

Llig `references/normativa-cv.md` (regla dels codis curriculars), l'apartat de l'etapa de `references/etapes.md`, `references/llengua.md` i `references/privacitat.md`.

## Flux
1. Recull (una sola tanda, amb botons si n'hi ha):
   - etapa, curs i àrea o mòdul;
   - què s'avalua (producte, procés, exposició, treball en equip, pràctica de taller…);
   - instrument: rúbrica analítica (recomanada), holística, llista de control, diana o escala d'observació;
   - nombre de nivells (recomanat: 4) i si vol vinculació explícita amb criteris oficials.
2. Genera directament. Si el docent dona una activitat o una SA, deriva'n els criteris tu mateix.

## Construcció
- **Criteris**: entre 3 i 6. Cada fila es vincula a un criteri d'avaluació del currículum (codi i redacció si el tens; si l'has derivat, marca'l com a proposta editable).
- **Nivells**: per defecte, *En inici · En procés · Assolit · Excel·lent*. En Primària i ESO, si el docent ho vol, fes-los correspondre amb l'escala de l'etapa (Insuficient, Suficient, Bé, Notable, Excel·lent). En Batxillerat i FP, indica el rang numèric de cada nivell.
- **Descriptors**: observables i progressius. Cada nivell descriu què es fa, no adjectius buits ("bé", "molt bé"). Evita descriure el nivell baix només amb negacions: digues també què ja aconseguix.
- **Pesos**: per criteri, que sumen 100 %. Calcula i mostra com s'obté la nota.
- **Infantil**: no fes rúbriques amb nota. Fes una escala d'observació (Ho fa amb ajuda · Ho fa sovint · Ho fa de manera autònoma) amb indicadors observables en el joc i les rutines, i un espai per a anotacions.

## Entrega
1. **Rúbrica del docent**: taula amb criteris, codis, descriptors i pesos, i una línia sobre com calcular la qualificació.
2. **Versió per a l'alumnat**: el mateix contingut en primera persona i llenguatge de l'edat ("He explicat les meues idees en ordre…"), útil per a autoavaluació i coavaluació. Per a Infantil i el primer cicle de Primària, amb emoticones o semàfor.
3. Opcional, si el docent ho demana: un **full de càlcul** amb la rúbrica i la fórmula de qualificació, o una diana d'autoavaluació.

## Comprovació
- Cada descriptor és observable i diferent del nivell veí.
- Els pesos sumen 100 %.
- La versió de l'alumnat s'entén sense ajuda.
- Revisió lingüística.

## Format
Taula en document editable si l'entorn l'oferix; si no, .docx amb la skill de Word, o full de càlcul si en vol. Oferix en una línia preparar el feedback de les faenes amb esta rúbrica (`feedback-formatiu`).
